"""用户端发版包的校验与安装（引导包和核心包里都有）。仅依赖 Python 3.8+ 标准库

- canonical / verify_sig：版本信息文件（latest.json、bootstrap.json）的发版签名。
  RSA-3072、PKCS#1 v1.5、SHA-256；公钥内置在下面的常量块里，由 scripts/release.py keygen 改写。
  与发版端共用测试向量 tests/vectors/release_sign_v1.json。
- verify_manifest：包内 manifest.json 逐个文件核对 sha256，多文件、少文件、改文件都算不一致。
- install_zip / recover：解压到 app.new → 校验 → app 改名 app.old → app.new 改名 app → 删 app.old；
  任何一步失败都保留原来的 app/。中途崩溃留下的半成品由 recover() 在下次启动时收拾。
- install_lock：<home>/app.lock 安装锁（O_CREAT|O_EXCL 建文件，记 pid 和时间，持锁期间一直拿着它的 flock），
  同一时间只有一个进程安装；拿不到就抛 LockBusy，不等待。持锁进程已退出（flock 已释放）或锁太旧时视为过期锁，可以接手。
- flock_held / create_flocked：跨对话窗口判断「另一个进程还在不在」。豆包云电脑每个对话窗口是一台独立沙箱
  （主机名、进程号各自独立，家目录共用），别的窗口里的进程号在这里看不到，只有 flock 跨窗口有效。
- fetch_core：用设备凭证从云端取 latest.json → 验签 → 下载核心包 → 校验 → 原子安装。
  验签通过后把这次检查记进 <home>/update.json（read_state / write_state），自动升级按它做 1 小时缓存。
- strip_core：订单失效时按 manifest 删掉核心文件，只留引导器，并把 manifest 改写成只含引导器文件。

所有失败都抛 UpdateError，不在这里调用 finish()，由 clipflow.py 决定怎么告诉用户。
"""
import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import sys
import tempfile
import time
import zipfile
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

try:
    import fcntl
except ImportError:  # 没有 fcntl 的系统（维护者在 Windows 上跑测试）：锁退回只看进程号
    fcntl = None

# --- release-pubkey begin ---
PUBKEY_N = 0xc199296f717639d3be61cf30c60e25e91512317c70ee30b76aab0f7671566d3203367d93655a3699c68743910a819fe529d0465cb1cc67e6bc9bd67e4e0ca1bd8d48ff69dc1ce8c8c380b2ae1194c2a3b63bf5cbaea0eadf1fde33adf34f45744ce0fe35620233a935c6d0e118a49747079b8cb5f255a6d5513cad2bbcae8eeb5230e6bf804b5e5effc8b45e507c0aa7728fc25322ea89ac108c4c08384b57082d769e47b07d5aad5fa4b19548dec668e7474cafab38fe7fc7a80f1b956eb58287592e2b9103709773c2ddd68881f9782caf9cafc35ace312ab18ece075681392e2951d5eee0dc505ec73a4ae8c8abbaa5927c8eccda14580004ef040b9203108ea64ad73a9139b1c7a2f6c6d273b5ff31a5f892f05a8c88b1e16e40b07d098a3727e40a9b9672a2494d703f94fd5a4c1f80c9b2dd5f5b51959f6ba7f666d569442ea0da4084b064680c4f0a4f72d299d0e93ee69b33eeefce01036c0553e0ae5e0f96df441d2d3cde33190748055f985d205553339279c0f9da61b907e32777
PUBKEY_E = 65537
# --- release-pubkey end ---

MANIFEST = "manifest.json"
# 包内不该出现、但用户机上运行后会自动生成的文件：核对 manifest 时忽略
_IGNORED_DIRS = {"__pycache__"}
_IGNORED_SUFFIXES = (".pyc",)
_IGNORED_NAMES = {".DS_Store"}
MAX_UNPACKED = 200 * 1024 * 1024  # 解压后的总大小上限，防止异常的压缩包把磁盘写满
_VERSION_RE = re.compile(r"\d+\.\d+\.\d+")
# EMSA-PKCS1-v1_5 里 SHA-256 的 DigestInfo 前缀（RFC 8017 §9.2 注 1）
_SHA256_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")


LOCK = "app.lock"
LOCK_STALE = 15 * 60          # 锁超过这么久还在，视为持锁进程卡死或已退出（安装一般只要几秒）
_DOWNLOAD_PREFIX = ".download-"  # 下载中的核心包临时文件（<home>/.download-*.zip）
LATEST_PATH = "/api/v1/skill/latest"
PACKAGE_PATH = "/api/v1/skill/package/"
# 升级检查记录：{"checked_at": 秒, "latest": "2.2.0", "blocked": "python"（新版要求更高的 Python 时才有）,
# "failed_at": 秒, "last_error": "..."（自动检查失败时 clipflow.py 记下，用于退避；检查成功后清掉），
# 以及别的子功能的字段（如 patches_sent）}。写入时只改自己的字段，其余原样保留
UPDATE_STATE = "update.json"


class UpdateError(Exception):
    """下载、校验、安装任一步失败"""


class LockBusy(UpdateError):
    """另一个进程正在安装或更新（这次跳过，不等待）"""


class PythonTooOld(UpdateError):
    """新版本要求更高的 Python（latest.json 的 min_python）。required 为要求的版本（如 3.10）"""

    def __init__(self, required: str):
        super().__init__(f"新版本要求 Python {required} 以上，当前是 {sys.version_info[0]}.{sys.version_info[1]}")
        self.required = str(required)


# ── 版本号 ──────────────────────────────────────────
def parse_version(s) -> tuple:
    """「主.次.修订」三段整数；格式不对抛 ValueError（源码里的 0.0.0-dev 也算不对）"""
    s = str(s or "").strip()
    if not _VERSION_RE.fullmatch(s):
        raise ValueError(f"版本号格式不对：{s!r}")
    return tuple(int(x) for x in s.split("."))


def newer(a, b) -> bool:
    """a 是否比 b 新；b 不是合法版本号（如开发版）时，任何合法的 a 都算更新"""
    try:
        vb = parse_version(b)
    except ValueError:
        vb = (-1,)
    return parse_version(a) > vb


# ── 发版签名 ────────────────────────────────────────
def canonical(obj) -> bytes:
    """签名覆盖的字节串：去掉 sig 字段后的规范化 JSON（键排序、无空格、保留中文）"""
    body = {k: v for k, v in obj.items() if k != "sig"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _emsa_pkcs1_v15(data: bytes, k: int) -> bytes:
    t = _SHA256_PREFIX + hashlib.sha256(data).digest()
    if k < len(t) + 11:
        raise ValueError("公钥太短")
    return b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t


def verify_sig(obj, pubkey=None) -> bool:
    """校验版本信息文件的发版签名。pubkey=(n, e)，省略时用内置公钥（调用时读取，测试可以打桩）"""
    n, e = pubkey or (PUBKEY_N, PUBKEY_E)
    if not isinstance(obj, dict) or not isinstance(obj.get("sig"), str):
        return False
    try:
        sig = base64.b64decode(obj["sig"].encode("ascii"), validate=True)
    except (binascii.Error, ValueError, UnicodeEncodeError):
        return False
    k = (n.bit_length() + 7) // 8
    if len(sig) != k:
        return False
    s = int.from_bytes(sig, "big")
    if s >= n:
        return False
    try:
        expected = _emsa_pkcs1_v15(canonical(obj), k)
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(pow(s, e, n).to_bytes(k, "big"), expected)


# ── manifest ────────────────────────────────────────
def sha256_file(p) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_rel(name: str) -> PurePosixPath:
    """包内相对路径：拒绝绝对路径、盘符、冒号、反斜杠和 ..（zip slip）"""
    if not name or "\\" in name or name.startswith("/") or "\x00" in name:
        raise UpdateError(f"包内路径不合法：{name!r}")
    rel = PurePosixPath(name)
    # 冒号：正常的包里不会有（盘符、备用数据流之类的写法），一律拒绝
    if any(part in ("", ".", "..") or ":" in part for part in rel.parts):
        raise UpdateError(f"包内路径不合法：{name!r}")
    return rel


def _ignored(rel: PurePosixPath) -> bool:
    return (any(part in _IGNORED_DIRS for part in rel.parts) or rel.name in _IGNORED_NAMES
            or rel.name.endswith(_IGNORED_SUFFIXES))


def list_files(root: Path) -> list:
    """root 下所有文件的相对路径（/ 分隔），不含运行时自动生成的缓存文件"""
    root = Path(root)
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _IGNORED_DIRS]
        for fn in filenames:
            rel = PurePosixPath(Path(dirpath, fn).relative_to(root).as_posix())
            if not _ignored(rel):
                out.append(str(rel))
    return sorted(out)


def read_manifest(root: Path) -> dict:
    try:
        m = json.loads((Path(root) / MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise UpdateError(f"manifest.json 读取失败：{e}") from e
    if (not isinstance(m, dict) or not isinstance(m.get("files"), dict)
            or not isinstance(m.get("bootstrap_files"), list) or not isinstance(m.get("version"), str)):
        raise UpdateError("manifest.json 格式不对")
    return m


def verify_manifest(root: Path) -> dict:
    """按 manifest.json 核对 root 下每个文件；有增、删、改，或 VERSION 与 manifest 不符时抛 UpdateError"""
    root = Path(root)
    m = read_manifest(root)
    files = m["files"]
    for rel in files:
        _safe_rel(rel)
    actual = set(list_files(root)) - {MANIFEST}
    missing = sorted(set(files) - actual)
    extra = sorted(actual - set(files))
    if missing or extra:
        raise UpdateError(f"文件和 manifest 对不上：缺少 {missing[:5]}，多出 {extra[:5]}")
    changed = [rel for rel, digest in files.items() if sha256_file(root / rel) != digest]
    if changed:
        raise UpdateError(f"文件内容和 manifest 对不上：{changed[:5]}")
    if "VERSION" in files and (root / "VERSION").read_text(encoding="utf-8").strip() != m["version"]:
        raise UpdateError("VERSION 和 manifest 里的版本号不一致")
    return m


# ── 安装 ────────────────────────────────────────────
def _rmtree(p: Path):
    if p.is_symlink() or p.is_file():
        p.unlink()
    elif p.exists():
        shutil.rmtree(p)


def _discard(p: Path):
    """尽量删掉，删不掉（例如没有权限）也不报错：失败路径上不能让清理掩盖真正的原因"""
    try:
        _rmtree(p)
    except OSError:
        pass


def recover(home):
    """启动时调用：上次替换到一半就崩了的话，把本机恢复成完整的一个版本。
    另一个进程正在安装（持有安装锁）时什么都不做，免得删掉它正在解压的 app.new"""
    home = Path(home)
    if _locked_by_other(home):
        return
    app, old, new = home / "app", home / "app.old", home / "app.new"
    if not app.exists() and old.is_dir():
        os.replace(old, app)  # 旧版已改名、新版还没换上：退回旧版
    # 下载到一半的临时包：本进程正持锁安装时，那就是正在用的那个，不能删
    leftovers = [] if _lock_key(home) in _HELD else list(home.glob(_DOWNLOAD_PREFIX + "*"))
    for p in (new, old, *leftovers):
        _discard(p)  # 删不掉不影响当前的 app/，下次再删


def _extract(zip_path, dest: Path):
    total = 0
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                _safe_rel(info.filename.rstrip("/"))
                continue
            rel = _safe_rel(info.filename)
            total += info.file_size
            if total > MAX_UNPACKED:
                raise UpdateError("压缩包解压后太大")
            target = dest.joinpath(*rel.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)


def install_zip(zip_path, home, expect_sha256=None) -> dict:
    """把发版包原子地装到 home/app。成功返回包内 manifest；失败抛 UpdateError，原来的 app/ 不变。
    安装期间持有安装锁（本进程已持有时直接复用），别的进程正在安装时抛 LockBusy"""
    with install_lock(home):
        return _install_zip(zip_path, Path(home), expect_sha256)


def _install_zip(zip_path, home: Path, expect_sha256=None) -> dict:
    app, old, new = home / "app", home / "app.old", home / "app.new"
    try:
        home.mkdir(parents=True, exist_ok=True)
        recover(home)
    except OSError as e:
        raise UpdateError(f"清理上次没装完的文件失败：{e}") from e
    if new.exists() or old.exists():
        raise UpdateError("上次留下的 app.new / app.old 删不掉（可能被占用），稍后再试")
    try:
        if expect_sha256 and sha256_file(zip_path) != expect_sha256.lower():
            raise UpdateError("压缩包的 sha256 和版本信息不一致")
        new.mkdir()
        _extract(zip_path, new)
        m = verify_manifest(new)
    except UpdateError:
        _discard(new)
        raise
    except Exception as e:  # noqa: BLE001  坏包可能抛 BadZipFile、zlib.error、RuntimeError（加密）、NotImplementedError（压缩算法）等
        _discard(new)
        raise UpdateError(f"解压失败：{e}") from e
    # 替换：两次改名之间崩溃时，recover() 会把 app.old 改回来
    try:
        if app.exists():
            os.replace(app, old)
        try:
            os.replace(new, app)
        except OSError:
            if old.exists() and not app.exists():
                os.replace(old, app)
            raise
    except OSError as e:
        _discard(new)
        raise UpdateError(f"替换失败：{e}") from e
    _discard(old)  # 删不掉不影响新版，下次 recover() 再删
    return m


# ── 安装锁 ──────────────────────────────────────────
_HELD = {}  # 本进程持有的锁：home 绝对路径 → [token, 嵌套层数, 拿着 flock 的 fd]


def _lock_key(home: Path) -> str:
    return os.path.normcase(os.path.abspath(str(home)))


def flock_held(p) -> "bool | None":
    """另一个进程正用 flock 拿着 p：True；没人拿着：False；文件不在、没有 fcntl 时判断不了：None。
    豆包云电脑每个对话窗口是一台独立沙箱（2026-11-03 实测两个窗口 hostname 不同）：家目录共用，主机名、进程号各自独立，
    别的窗口里的进程号在这里用 os.kill 看不到。跨窗口能判断「另一个进程还在不在」的只有 flock（进程退出、被杀时自动释放）。
    只试一下共享锁，拿到了马上放开；本进程自己拿着时也返回 True（调用方先用 token 认出自己的锁）"""
    if fcntl is None:
        return None
    try:
        fd = os.open(str(p), os.O_RDONLY)
    except OSError:
        return None
    try:
        fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
    except OSError:
        return True
    else:
        fcntl.flock(fd, fcntl.LOCK_UN)
        return False
    finally:
        os.close(fd)


def create_flocked(p: Path, data: str):
    """O_CREAT|O_EXCL 建锁文件，先拿 flock 再写内容（别人读到内容时锁已经拿着了），返回一直开着的 fd；
    文件已经存在返回 None。调用方用完先删文件再 os.close(fd)；进程退出、被杀时 flock 自动释放。
    没有 fcntl 时只建文件、写内容（锁退回只看进程号）"""
    try:
        fd = os.open(str(p), os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        return None
    try:
        if fcntl is not None:
            fcntl.flock(fd, fcntl.LOCK_EX)  # 别人探测时只短暂拿共享锁，这里等一下就能拿到
        os.write(fd, data.encode("utf-8"))
    except BaseException:
        os.close(fd)
        _discard(p)
        raise
    return fd


def lock_data(**fields) -> str:
    """锁文件的内容：调用方的字段，有 fcntl 时加上 "flock": 1（这把锁的存活看 flock，不看进程号）"""
    if fcntl is not None:
        fields["flock"] = 1
    return json.dumps(fields)


def _pid_alive(pid: int) -> bool:
    """进程是否还在；判断不了时当作还在（宁可这次跳过，也不抢别人的锁）"""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except OSError:
        return True  # 没权限等：进程在
    return True


def _read_lock(p: Path):
    """(原文, 解析结果)；文件不在返回 (None, None)，内容坏了返回 (原文, None)"""
    try:
        raw = p.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None, None
    except OSError:
        return "", None
    try:
        info = json.loads(raw)
    except ValueError:
        return raw, None
    return raw, info if isinstance(info, dict) else None


def _lock_stale(p: Path, info) -> bool:
    now = time.time()
    if info is None:
        # 刚建好、还没写进内容的锁也读不出东西：只有放了一阵子的坏锁才算过期
        try:
            return now - p.stat().st_mtime > 30
        except OSError:
            return False
    try:
        pid, ts = int(info.get("pid") or 0), float(info.get("ts") or 0)
    except (TypeError, ValueError):
        return True
    if now - ts > LOCK_STALE:
        return True
    if info.get("flock"):
        held = flock_held(p)
        if held is not None:
            return not held  # 持锁进程可能在另一个对话窗口里，进程号这里看不到
    return not _pid_alive(pid)


def _try_create(p: Path, data: str) -> bool:
    try:
        fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        return False
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(data)
    return True


def _break_stale(p: Path, seen: str) -> bool:
    """接手过期锁：先改名挪开，确认挪走的正是刚才判定过期的那把（没被别人抢先换掉）"""
    aside = p.with_name(f"{p.name}.stale-{secrets.token_hex(4)}")
    try:
        os.replace(str(p), str(aside))
    except OSError:
        return False
    try:
        got = aside.read_text(encoding="utf-8")
    except OSError:
        got = None
    if got != seen:
        # 挪走的是别人刚建的新锁：尽量放回去，这次不抢
        try:
            if not p.exists():
                os.replace(str(aside), str(p))
        except OSError:
            pass
        _discard(aside)
        return False
    _discard(aside)
    return True


def _locked_by_other(home: Path) -> bool:
    if _lock_key(home) in _HELD:
        return False
    p = home / LOCK
    raw, info = _read_lock(p)
    return raw is not None and not _lock_stale(p, info)


@contextmanager
def install_lock(home):
    """<home>/app.lock：同一时间只有一个进程安装或更新。拿不到立即抛 LockBusy，不等待。
    同一进程里可以嵌套（fetch_core 持锁后再调 install_zip）"""
    home = Path(home)
    key = _lock_key(home)
    if key in _HELD:
        _HELD[key][1] += 1
        try:
            yield
        finally:
            _HELD[key][1] -= 1
        return
    try:
        home.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise UpdateError(f"建不了数据目录：{e}") from e
    p = home / LOCK
    token = secrets.token_hex(8)
    data = lock_data(pid=os.getpid(), ts=int(time.time()), token=token)
    try:
        fd = create_flocked(p, data)
        if fd is None:
            raw, info = _read_lock(p)
            if raw is not None and not _lock_stale(p, info):
                raise LockBusy("另一个进程正在安装或更新即用创作小助手")
            if raw is not None and not _break_stale(p, raw):
                raise LockBusy("另一个进程正在安装或更新即用创作小助手")
            fd = create_flocked(p, data)
            if fd is None:
                raise LockBusy("另一个进程正在安装或更新即用创作小助手")
    except OSError as e:
        raise UpdateError(f"安装锁建不了：{e}") from e
    _HELD[key] = [token, 1, fd]
    try:
        yield
    finally:
        del _HELD[key]
        raw, info = _read_lock(p)
        if info and info.get("token") == token:  # 只删自己的锁；先删文件再放 flock
            _discard(p)
        os.close(fd)


# ── 从云端补全 / 更新核心包 ──────────────────────────
def local_version(home) -> str:
    try:
        return (Path(home) / "app" / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def has_core(home) -> bool:
    """home/app 里有没有完整的核心文件（manifest 里引导器以外的文件都在）"""
    app = Path(home) / "app"
    try:
        m = read_manifest(app)
    except UpdateError:
        return False
    core = set(m["files"]) - set(m["bootstrap_files"])
    return bool(core) and all((app / rel).is_file() for rel in core)


def python_ok(required) -> bool:
    """当前 Python 是否满足版本信息里的 min_python（如 "3.8"）；没写或写错时不拦"""
    try:
        need = tuple(int(x) for x in str(required).split("."))
    except ValueError:
        return True
    return not required or tuple(sys.version_info[:len(need)]) >= need


def read_state(home) -> dict:
    """<home>/update.json；没有或读坏了返回空字典"""
    try:
        obj = json.loads((Path(home) / UPDATE_STATE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return obj if isinstance(obj, dict) else {}


def write_state(home, **fields) -> dict:
    """改写 update.json 里的若干字段（值为 None 表示删掉这个字段），其余字段原样保留。
    每次写一个本进程独有的临时文件再替换：两个命令同时写时 update.json 不会被写成半截
    （最多其中一方的改动被另一方覆盖）"""
    home = Path(home)
    st = read_state(home)
    for k, v in fields.items():
        if v is None:
            st.pop(k, None)
        else:
            st[k] = v
    home.mkdir(parents=True, exist_ok=True)
    p = home / UPDATE_STATE
    fd, tmp = tempfile.mkstemp(prefix=UPDATE_STATE + ".", suffix=".tmp", dir=str(home))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(st, ensure_ascii=False, indent=2))
        os.replace(tmp, str(p))
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return st


def _record_check(home: Path, version: str, blocked):
    """验签通过才记：请求失败不记，下一条命令再试。同时清掉自动检查失败的退避记录。
    写不进去不影响升级本身"""
    try:
        write_state(home, checked_at=int(time.time()), latest=version, blocked=blocked,
                    failed_at=None, last_error=None)
    except OSError:
        pass


def parse_info(raw: bytes) -> dict:
    """解析并验签版本信息（latest.json / bootstrap.json），不合格抛 UpdateError"""
    try:
        info = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as e:
        raise UpdateError(f"版本信息不是合法的 JSON：{e}") from e
    if not verify_sig(info):
        raise UpdateError("版本信息的发版签名校验没通过")
    try:
        parse_version(info.get("version"))
    except ValueError as e:
        raise UpdateError(str(e)) from e
    if not re.fullmatch(r"[0-9a-fA-F]{64}", str(info.get("sha256") or "")):
        raise UpdateError("版本信息里的 sha256 格式不对")
    return info


def fetch_core(server_url, cred, home, force=False, latest_timeout=30, package_timeout=60):
    """用设备凭证从云端补全或更新核心包，返回装上的版本号；本机已有不低于云端版本的核心包时返回 None。
    force：本机版本不低于云端也重新装一遍。版本信息验签通过后把这次检查记进 update.json
    （checked_at、latest；新版要求的 Python 比当前高时记 blocked="python"，否则清掉 blocked）。
    不调用 finish()：云端 401 抛 mcp_client.AuthError、426 抛 SkillOutdated，网络不通抛 ConnectError，
    其他失败抛 UpdateError（另一个进程正在安装时是 LockBusy，Python 太旧是 PythonTooOld），
    由 clipflow.py 决定怎么告诉用户"""
    import mcp_client  # 引导包里一定有；放在这里导入，install.py 单独加载本模块时用不到它
    home = Path(home)
    info = parse_info(mcp_client.signed_get(server_url, LATEST_PATH, cred, timeout=latest_timeout))
    version = info["version"]
    wanted = force or not has_core(home) or newer(version, local_version(home))
    py_ok = python_ok(info.get("min_python"))
    _record_check(home, version, "python" if wanted and not py_ok else None)
    if not wanted:
        return None
    if not py_ok:
        raise PythonTooOld(info.get("min_python"))
    with install_lock(home):
        data = mcp_client.signed_get(server_url, PACKAGE_PATH + version, cred, timeout=package_timeout)
        try:
            fd, tmp = tempfile.mkstemp(prefix=_DOWNLOAD_PREFIX, suffix=".zip", dir=str(home))
        except OSError as e:
            raise UpdateError(f"保存安装包失败：{e}") from e
        try:
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(data)
            except OSError as e:  # 磁盘满等
                raise UpdateError(f"保存安装包失败：{e}") from e
            install_zip(tmp, home, expect_sha256=info["sha256"])
        finally:
            _discard(Path(tmp))
    return version


# ── 订单失效：只留引导器 ─────────────────────────────
def _core_files(app: Path):
    """manifest 里引导器以外的文件；manifest 缺失、损坏或有不合法的路径时返回 None"""
    try:
        m = read_manifest(app)
        for rel in m["files"]:
            _safe_rel(rel)
    except UpdateError:
        return None, None
    boot = set(m["bootstrap_files"])
    return m, sorted(rel for rel in m["files"] if rel not in boot)


def strip_core(home) -> list:
    """按 home/app/manifest.json 删掉引导器以外的文件（含它们的 __pycache__ 和变空的目录），
    再把 manifest 改写成只列引导器文件，之后 verify_manifest 仍然通过。返回删掉的文件。
    manifest 缺失、损坏，或里面有不合法的路径时一个文件都不删（宁可不删，不能误删）；
    另一个进程正在安装时这次也不删（抛 LockBusy）"""
    app = Path(home) / "app"
    m, core = _core_files(app)
    if not core:
        return []
    removed = []
    with install_lock(home):
        m, core = _core_files(app)  # 拿到锁后重读：等锁期间可能刚装上别的版本
        if not core:
            return []
        boot = set(m["bootstrap_files"])
        # 先删文件、最后改写 manifest：删到一半崩了，manifest 里还列着剩下的核心文件，下次失效时接着删
        dirs = set()
        for rel in core:
            p = app.joinpath(*PurePosixPath(rel).parts)
            try:
                if p.is_file() or p.is_symlink():
                    p.unlink()
                    removed.append(rel)
            except OSError:
                continue
            if p.suffix == ".py":
                for c in p.parent.glob(f"__pycache__/{p.stem}.*.pyc"):
                    _discard(c)
                dirs.add(p.parent / "__pycache__")
            parent = p.parent
            while parent != app:
                dirs.add(parent)
                parent = parent.parent
        for d in sorted(dirs, key=lambda x: len(x.parts), reverse=True):
            try:
                d.rmdir()  # 只删空目录
            except OSError:
                pass
        left = [rel for rel in core if app.joinpath(*PurePosixPath(rel).parts).exists()]
        if not left:  # 有删不掉的就保留原 manifest，下次再删
            kept = dict(m, files={rel: d for rel, d in m["files"].items() if rel in boot})
            tmp = app / (MANIFEST + ".tmp")
            tmp.write_text(json.dumps(kept, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                           encoding="utf-8")
            os.replace(str(tmp), str(app / MANIFEST))
    return removed

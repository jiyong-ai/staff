#!/usr/bin/env python3
"""短剧剪辑助手 · 用户端命令行（入口）

这个文件是入口和引导器：输出协议、本机配置、设备激活、云端调用这些共用基础都在这里，
另外负责 status / setup / guide / upgrade / consent 五条命令和用户服务协议的门禁。其余命令（环境、素材、台词、草稿、配音、合成、发布……）
在核心包的 flow.py / publish_flow.py 里，订单号验证通过后才会下发；flow.py 不存在时，这些命令统一返回
need_order（还没激活）或 core_missing（已激活，核心功能还没下载好）。仅依赖 Python 3.8+ 标准库。

用法:  python3 clipflow.py <命令> [参数]
命令:
  guide             打印完整流程说明，再告诉你当前状态和下一步（每次使用先运行它）
  status            查看激活状态与任务进度，告诉你下一步
  setup             激活：用商城订单编号把这台电脑绑定到课程服务
  upgrade           立即检查并补全 / 升级到最新版本
  consent           用户服务协议：没同意过当前版本时给出要发给用户的协议链接；consent --agree 记下用户已同意
  check-env         检查 / 补装剪辑要用的运行环境
  claim             列推荐片单给用户选；--pick / --auto 领取用户选好的剧（剧名 + 飞书文件夹链接），领到后接着准备素材
  material          当前任务：下载整部剧、识别台词
  wait              继续等待下载和台词识别
  subs-check        回传字幕抽查结论（ok / bad；bad 会反馈给即用客服，再给用户新的推荐片单）
  script            重新打印台词脚本
  task-issue        当前任务的素材有问题：反馈给即用客服，再给用户新的推荐片单
  submit            编译草稿 → 本机格式检查 → 云端判定 → 给用户看方案
  plan-ok           用户认可了方案：列出要配音的段
  tts               收进配音 → 合成、测量 → 云端判定成片 → 等用户确认发布
  result            继续等待成片（判定时云端没连上，重跑只重新判定）
  publish           用户确认发布后运行：先问云端名额，再由本机发布助手接任务、填好发布页 → 点发布 → 回传结果
  abandon           用户不发这一条了：结束这次领取，再给用户新的推荐片单
  publish-choice    用户回答「是否需要通过豆包帮你发布」：--yes 照原流程装发布功能、登录；--no 这一条只剪辑，做好把成片发给用户
  report            回传发布结果（pending_check 后用户确认用）
  check-publisher   检查本机发布助手与发布账号登录状态
  install-publisher 安装 / 修复本机发布助手
  publisher-selftest  发布出问题后联调发布页（不会真的发布）
  wait-login        用户说扫好了 / 刷好了以后看发布账号登录好了没有
  phone-login       手机号 + 验证码登录发布账号（用户在豆包手机 App 上、扫不了自己屏幕上的码时）
  login-qr          这次登录改用扫码（手机端用户想扫码，或者手机号登录走不通）
  face-retry        刷脸码过期、用户要重发（只在刷脸时用：手机号登录的重新走一遍手机号登录，扫码登录的重新截一张）
  sms-send          重新发送短信验证码（扫码后的身份验证、手机号登录）
  sms-verify        填入用户报来的短信验证码（扫码后的身份验证、手机号登录都用它）
  logout            退出当前发布账号、返回新登录二维码（账号不满足任务条件、用户同意换账号时）

每条命令最后固定输出三行：
  STATUS: 状态码
  SAY:    要转告用户的话
  NEXT:   接下来该做什么
"""
import argparse
import hashlib
import json
import os
import re
import shlex
import sys
import time
from datetime import datetime
from pathlib import Path

# 以脚本方式运行时本模块是 __main__：登记成 clipflow，flow.py 再 import clipflow 时拿到的是同一份
# （同一个 Finish 类、同一个 _SESSION），否则 flow 抛出的 Finish 入口接不住
sys.modules.setdefault("clipflow", sys.modules[__name__])

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import device  # noqa: E402
import doubao_env  # noqa: E402
import updater  # noqa: E402
from mcp_client import (ActivateError, AuthError, ConnectError, Credential,  # noqa: E402
                        MCPClient, MCPError, SkillOutdated, ToolError, activate, normalize_url)

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

HOME = Path(os.environ.get("CLIPFLOW_HOME") or (Path.home() / ".clipflow"))
DEFAULT_WAIT = int(os.environ.get("CLIPFLOW_MAX_WAIT", "480"))
# 用户端用到的云端工具（setup 时核对云端有没有）
CLOUD_TOOLS = {"list_recommendations", "claim_task", "check_decision", "check_video", "report_task_issue",
               "confirm_publish", "abandon_task", "report_publish", "report_page_issue"}


# ── 输出协议 ─────────────────────────────────────────
class Finish(Exception):
    def __init__(self, status, say="", nxt="", code=0):
        super().__init__(status)
        self.status, self.say, self.nxt, self.code = status, say, nxt, code


def finish(status, say="", nxt="", code=0):
    raise Finish(status, say, nxt, code)


def log(msg=""):
    print(msg, flush=True)


def now():
    return datetime.now().strftime("%H:%M:%S")


def _sh_quote(p: str) -> str:
    """POSIX shell 引号：含单引号、但没有 shell 在双引号里还会展开的字符时用双引号
    （安装命令 -c "...urlopen('...')..." 就是这种），其余交给 shlex.quote"""
    if "'" in p and not any(ch in p for ch in '"$`\\!'):
        return f'"{p}"'
    return shlex.quote(p)


def _cmdline(parts) -> str:
    return " ".join(_sh_quote(str(p)) for p in parts)


def cmd(*args) -> str:
    """生成可直接复制运行的命令行（绝对路径，与当前解释器一致）"""
    return _cmdline([sys.executable, str(HERE / "clipflow.py"), *args])


def retry_cmd() -> str:
    """重新运行本条命令（main 收到的参数；在进程内调用 main(argv) 时 sys.argv 不是这条命令）"""
    return cmd(*(_SESSION.get("argv") or sys.argv[1:]))


# ── 本地存储 ─────────────────────────────────────────
def read_json(p, default):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def write_json(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, p)


def safe_name(s: str) -> str:
    return re.sub(r'[\\/:*?"<>|\s\']+', "_", str(s)).strip("_.") or "task"


def user_config() -> dict:
    return read_json(HOME / "config.json", {})


def save_user_config(**kw):
    cfg = user_config()
    cfg.update(kw)
    write_json(HOME / "config.json", cfg)


def load_config() -> dict:
    cfg = {"server_url": "", "order_no": ""}
    for src in (read_json(HERE / "defaults.json", {}), user_config()):
        cfg.update({k: v for k, v in src.items() if v})
    cfg.pop("publisher_url", None)  # 以前的版本记过本机发布助手的地址；现在发布助手不监听端口，不用了
    if os.environ.get("CLIPFLOW_SERVER"):
        cfg["server_url"] = os.environ["CLIPFLOW_SERVER"]
    return cfg



def mask(s: str) -> str:
    return s if len(s) <= 6 else f"{s[:3]}***{s[-3:]}"


# ── 用户原话解析 ─────────────────────────────────────
def parse_order(text: str) -> str:
    t = re.sub(r"\s+", "", text or "")
    t = re.sub(r"^(?:商城)?(?:订单编号|订单号|订单)[:：]?", "", t)
    if re.fullmatch(r"\d{6,}", t):
        return t
    found = re.findall(r"[A-Za-z0-9][A-Za-z0-9-]{5,}", t)
    return max(found, key=len) if found else t


# ── 云端调用与设备激活 ───────────────────────────────
def need_order():
    finish("need_order",
           "请发我你的商城订单编号（商城订单详情里的一串数字），我用它激活剪辑服务。",
           f"拿到订单号后运行：{cmd('setup', '--order', '<用户发来的订单号原话>')}")


def need_server():
    finish("need_server", "",
           "未配置云端服务地址：在 scripts/defaults.json 填 server_url，"
           f"或运行 {cmd('setup', '--server', '<http://服务器IP:8300>')}", 1)


# 本进程的设备凭证缓存。每次运行最多自动重新激活一次：两台电脑互相顶号时不会死循环
# reloaded：同时运行的另一个命令（或另一次 setup）已重新激活时，本进程最多换用一次本机最新凭证
# argv：本次运行的命令行参数（升级后重新执行用）；forced_upgrade：收到 skill_outdated 后已强制升级过一次
# say_notes / next_notes：命令开头顺带做的事要补充的话（add_note），输出时拼进 SAY / NEXT
# announced：这条命令已经把领到任务（带预期时长）告诉用户了，剪辑中途的进度话不再重复
_SESSION = {"credential": None, "reactivated": False, "reloaded": False, "argv": [], "forced_upgrade": False,
            "say_notes": [], "next_notes": [], "announced": False}
# 遇到这些 401 时用本机保存的订单号自动重新激活（signature_invalid：本机 kid 与密钥对不上）
REACTIVATE_CODES = {"credential_invalid", "credential_missing", "signature_invalid"}


def _order_lost():
    """本机已保存的订单被云端判定失效（停用、退款、过期）：删掉核心文件只留引导器。
    tasks/、发布助手、config.json 和密钥都不动：订单在后台恢复后，下一条命令会自动补回核心包"""
    try:
        removed = updater.strip_core(HOME)
        if removed:
            log(f"[{now()}] 订单已失效，已移除 {len(removed)} 个核心文件")
    except Exception as e:  # noqa: BLE001  清理失败不影响告诉用户订单失效
        log(f"[{now()}] 移除核心文件失败：{str(e)[:200]}")
    finish("order_lost", "订单已失效，请联系即用客服。",
           "把 SAY 转告用户，流程暂停；不要重试，也不要尝试其他办法绕过", 1)


def _auth_failed():
    finish("auth_failed",
           "订单号无效或已失效：请核对订单号是否输入正确；确认无误仍不行，请联系即用客服。",
           f"用户给出新的订单号后运行：{cmd('setup', '--order', '<订单号>')}", 1)


def _other_device():
    finish("other_device",
           "这个订单已在其他电脑激活。如果你换了电脑或重装了系统，请联系客服解绑。",
           "把 SAY 转告用户，流程暂停；不要重试，也不要尝试其他办法绕过。"
           f"客服解绑后，用户在要使用的电脑上运行：{cmd('setup', '--order', '<订单号>')}", 1)


def _device_unbound():
    # 云端已删除凭证：清掉本机凭证和订单号，避免下次运行时自动把这台电脑重新绑回去
    device.delete_secret(HOME)
    save_user_config(order_no="", kid="")
    _SESSION["credential"] = None
    finish("device_unbound",
           "这台电脑已解绑。请在新电脑上激活；如果仍要在这台电脑上用，请重新发我订单号。",
           f"用户要在这台电脑上继续用时，拿到订单号后运行：{cmd('setup', '--order', '<用户发来的订单号原话>')}", 1)


def _activate_limited():
    finish("activate_limited", "激活次数过多，请联系客服。", "把 SAY 转告用户，流程暂停，不要重试", 1)


def _device_unavailable():
    finish("device_unavailable", "没法识别这台电脑，请联系即用客服。",
           "把 SAY 转告用户，流程暂停。不要尝试修改脚本或用其他方式提供设备信息", 1)


def _secret_store_failed(err):
    finish("secret_store_failed", "这台电脑暂时没法记住激活状态，请稍后再试；一直不行请联系即用客服。",
           f"多半是数据目录没有写入权限或磁盘满了（{str(err)[:120]}）。处理后重新运行："
           f"{retry_cmd()}", 1)


def _clock_skew():
    finish("clock_skew", "这台电脑的时间不准，请在电脑的日期和时间设置里打开「自动设置时间」后再试。",
           f"用户校准时间后重新运行：{retry_cmd()}", 1)


def unsupported_env(reason):
    finish(doubao_env.UNSUPPORTED_STATUS, doubao_env.UNSUPPORTED_SAY, doubao_env.unsupported_next(reason), 1)


def require_doubao():
    """这个版本只在豆包云电脑上运行；不是就 unsupported_env（install-publisher 在第 1 步前也调它）"""
    ok, reason = doubao_env.check()
    if not ok:
        unsupported_env(reason)


# ── 用户服务协议（任务 11-04-original-creator-revamp 设计第 6 节）────────
# consent.json 记的版本不低于 CONSENT_VERSION 才算同意过。版本号和插件同一套：1 是 V1.0，2 是 V1.1。
# V1.1（2026-11-05 法务审过，云端协议页上线）起是 2：老用户升级后第一次用先同意（设计 6.5）。0 表示门禁关闭（测试用 monkeypatch 设）
CONSENT_VERSION = 2
CONSENT_FILE = "consent.json"
TERMS_TITLE = "《即用创作小助手用户服务协议》"   # 要和云端协议页标题（app/api/plugin/terms.py 的 TITLE）一致，tests/skill/test_consent.py 核对
# 请用户同意时先说清楚即用创作小助手做什么、不存什么：和插件、distribution/install.md、SKILL.md 同一句
CONSENT_NOTE = ("即用创作小助手帮你把选好的短剧剪成解说视频，经你确认后发布到你的账号，不会自己生产创作内容。"
                "你的账号登录只在你的豆包云电脑上，小助手不会保存你的账号密码等敏感信息。")
# 不过协议门禁的命令（设计 6.2）：consent 是同意本身；guide、status 要先把说明打出来，status 的后半段
# （flow.status_tail）第一件事就是门禁；setup、upgrade 是激活和补全，不算往下做；report 回传已经发生的结果；
# _job 是后台作业，起它的前台命令已经过了门禁
CONSENT_FREE = ("consent", "guide", "status", "setup", "upgrade", "report", "_job")


def terms_url(cfg) -> str:
    """协议页地址：server_url（…/mcp/）换成同一前缀下的 /plugin/terms，和 scripts/release.py 的 terms_url 同一个规则。
    运行时算，不写死在脚本里（引导包里不能有云端地址）。server_url 不是 MCP 端点时为空"""
    url = str(cfg.get("server_url") or "").rstrip("/")
    if not url.endswith("/mcp"):
        return ""
    return url[:-len("/mcp")] + "/plugin/terms"


def consent_record() -> dict:
    rec = read_json(HOME / CONSENT_FILE, {})
    return rec if isinstance(rec, dict) else {}


def _consent_version(rec) -> int:
    v = rec.get("version")
    return v if isinstance(v, int) and not isinstance(v, bool) else 0


def consent_ok() -> bool:
    """用户同意过的协议版本不低于当前的 CONSENT_VERSION（新版本记下的更高版本也认）"""
    return _consent_version(consent_record()) >= CONSENT_VERSION


def need_consent(retry=""):
    """请用户同意用户服务协议。retry：被拦下的命令，同意后先运行 guide 读完说明（流程有调整），再重新运行它"""
    url = terms_url(load_config())
    if not url:
        need_server()
    argv = _SESSION.get("argv") or []
    first = argv[0] if retry and argv else ""
    if first == "guide":
        then = f"，再重新运行：{retry}"
    elif first == "status":
        then = f"，再运行：{cmd('guide', *argv[1:])}（打印说明并接着给出下一步，按它最后的 NEXT 继续）"
    elif retry:
        then = f"，再运行 {cmd('guide')} 把说明从头读完（流程有调整），最后重新运行：{retry}"
    else:
        then = f"，再运行 {cmd('guide')} 把说明从头读完，按它最后的 NEXT 继续"
    finish("need_consent",
           f"{CONSENT_NOTE}开始之前，请先点开看一下{TERMS_TITLE}；同意的话回复我「同意」～",
           f"在这一轮最后一条回复里写 SAY，并把协议作为可点击的链接发给用户：写成 Markdown 链接 "
           f"[{TERMS_TITLE}]({url})，链接文字只写协议名，不要把网址单独贴出来，也不要把协议或说明里"
           f"「小助手会做什么」一节的内容整段贴给用户；发完结束这一轮。用户回复「同意」「确认」「可以」这类明确同意的话后运行："
           f"{cmd('consent', '--agree')}{then}。用户问具体会做什么，对照 guide 打印的说明里"
           f"「小助手会做什么」一节如实回答。用户没有明确同意之前，不要列片单、不要领取、不要安装剪辑环境、"
           f"不要安装发布功能、不要登录发布账号；手上做到一半的这部剧也先放着（不配音、不发布、不放弃）。"
           f"用户不同意或没有明确表态时停在这里，什么都不运行，也不要劝说；用户之后说同意了再运行上面的命令。"
           f"同意协议只是基础授权：之后的选剧、看方案、发布、发短信验证码，到了那一步照常等用户回复")


def require_consent():
    """没有同意记录，或同意的是旧版协议：need_consent（NEXT 带上被拦下的这条命令）。
    入口对 CONSENT_FREE 以外的命令、flow.status_tail 开头调它"""
    if not consent_ok():
        need_consent(retry_cmd())


def cmd_consent(a):
    if a.agree:
        rec = consent_record()
        now_dt = datetime.now()
        write_json(HOME / CONSENT_FILE, {"version": max(CONSENT_VERSION, _consent_version(rec)),
                                         "agreed_at": now_dt.isoformat(timespec="seconds"),
                                         "ts": int(now_dt.timestamp())})
        log(f"[{now()}] 已记下用户同意第 {CONSENT_VERSION} 版用户服务协议")
        finish("consent_ok", "",
               f"先运行 {cmd('guide')} 把说明从头读完（流程有调整；刚才被拦下的就是 guide 或 status 时，运行这一次就够了），"
               f"再重新运行刚才因为没同意协议被拦下的命令；没有被拦下的命令就运行：{cmd('claim')}"
               "（列出推荐片单给用户选；已经领过的会接着做）")
    if consent_ok():
        rec = consent_record()
        finish("consent_ok", "", f"用户已经同意过用户服务协议（{rec.get('agreed_at') or '时间未记录'}）。"
                                 f"运行：{cmd('claim')}（列出推荐片单给用户选；已经领过的会接着做）")
    need_consent()


def read_device_id() -> str:
    try:
        return device.device_id(HOME)
    except device.DeviceUnavailable:
        _device_unavailable()


def activate_device(server_url: str, order_no: str, retry_cmd: str, saved_order: bool = False) -> Credential:
    """用订单号激活本机：成功后先把密钥存进系统密钥库，再写 kid 和云端规范化后的订单号。
    失败时按错误码结束，不改动本机已有的 kid。
    saved_order：用的是本机已保存的订单号（自动重新激活）。这时订单被判定失效就收回核心文件；
    setup --order 新输入的订单号验证失败只提示核对，不删任何东西"""
    did = read_device_id()
    try:
        r = activate(server_url, order_no, did)
    except SkillOutdated as e:
        _skill_outdated(e)
    except ActivateError as e:
        if e.code == "other_device":
            _other_device()
        if e.code == "activate_limited":
            _activate_limited()
        if e.code in ("order_invalid", "order_revoked") and saved_order:
            _order_lost()
        if e.code in ("order_invalid", "order_revoked", "invalid_params"):
            _auth_failed()
        if e.code == "too_frequent":
            finish("network_error", "剪辑服务暂时繁忙，请稍等一两分钟再试。",
                   f"过一两分钟重新运行：{retry_cmd}", 1)
        finish("network_error", "剪辑服务暂时不可用，请稍后再试。",
               f"稍后重新运行：{retry_cmd}（错误：{e.code or e.http_status} {str(e)[:160]}）", 1)
    except ConnectError as e:
        finish("network_error", "暂时连不上剪辑服务，请检查电脑网络，稍后我再试。",
               f"网络恢复后重新运行：{retry_cmd}（错误：{str(e)[:200]}）", 1)
    try:
        device.save_secret(r["secret"], HOME)
    except device.SecretStoreError as e:
        _secret_store_failed(e)
    save_user_config(order_no=r["order_no"], kid=r["kid"])
    cred = Credential(r["kid"], r["secret"], did)
    _SESSION["credential"] = cred
    return cred


def reactivate(cfg) -> Credential:
    """用本机保存的订单号自动重新激活（迁移旧配置、密钥丢失、凭证失效），用户无感。每次运行最多一次"""
    _SESSION["reactivated"] = True
    _SESSION["credential"] = None
    log(f"[{now()}] 正在用已保存的订单号重新激活本机")
    return activate_device(cfg["server_url"], cfg["order_no"], retry_cmd(), saved_order=True)


def cloud(cfg=None) -> MCPClient:
    cfg = load_config()  # 以本机最新配置为准：同一次运行里可能刚重新激活过
    return MCPClient(cfg.get("server_url", ""), credential=credential(cfg), timeout=90)


def credential(cfg) -> Credential:
    """本机设备凭证：本进程缓存 → 本机 kid + 密钥库 → 用已保存的订单号重新激活"""
    if not cfg.get("server_url"):
        need_server()
    if not cfg.get("order_no"):
        need_order()
    cred = _SESSION["credential"]
    if cred is None:
        kid = cfg.get("kid", "")
        secret = device.load_secret(HOME) if kid else ""
        if kid and secret:
            cred = Credential(kid, secret, read_device_id())
            _SESSION["credential"] = cred
        elif _SESSION["reactivated"]:
            _auth_failed()
        else:
            cred = reactivate(cfg)  # 旧配置只有订单号，或密钥丢了
    return cred


def _reload_credential(cred: Credential):
    """本机配置里的 kid 已经不是本进程在用的那个（别的进程刚重新激活过）：直接换用，不再占用激活次数。
    每次运行最多一次；没有更新的凭证时返回 None"""
    if _SESSION["reloaded"]:
        return None
    kid = load_config().get("kid", "")
    if not kid or kid == cred.kid:
        return None
    secret = device.load_secret(HOME)
    if not secret:
        return None
    _SESSION["reloaded"] = True
    fresh = Credential(kid, secret, cred.device_id)
    _SESSION["credential"] = fresh
    return fresh


def handle_auth_error(c: MCPClient, e: AuthError):
    """云端 401：能自动恢复时换上新凭证后返回（调用方重试），否则按错误码结束"""
    if e.code in REACTIVATE_CODES and c.credential:
        fresh = _reload_credential(c.credential)
        if fresh is None and not _SESSION["reactivated"]:
            fresh = reactivate(load_config())
        if fresh is not None:
            c.credential = fresh
            c.ready = False
            return
    if e.code in ("other_device", "device_mismatch"):
        _other_device()
    if e.code == "device_unbound":
        _device_unbound()
    if e.code == "clock_skew":
        _clock_skew()
    if e.code in ("order_revoked", "order_invalid"):
        _order_lost()  # 签名请求被拒：说明本机已激活的订单失效了
    _auth_failed()


def call(c: MCPClient, tool: str, retries: int = 3, **args):
    """调用云端工具；网络抖动自动重试；凭证失效时自动重新激活一次，其他 401 按错误码结束"""
    i = 0
    while True:
        try:
            return c.call_tool(tool, args)
        except AuthError as e:
            handle_auth_error(c, e)
        except ToolError as e:
            return {"ok": False, "error": str(e)}
        except SkillOutdated as e:  # 不是网络抖动，重试没用
            _skill_outdated(e)
        except (ConnectError, MCPError) as e:
            if i >= retries:
                finish("network_error", "暂时连不上剪辑服务，请检查电脑网络，稍后我再试。",
                       f"网络恢复后重新运行：{retry_cmd()}（错误：{str(e)[:200]}）", 1)
            i += 1
            wait = 5 * i
            log(f"[{now()}] 网络波动，{wait}s 后重试：{str(e)[:120]}")
            time.sleep(wait)
            c.ready = False



# ── 核心包 ──────────────────────────────────────────
# 引导器自带的命令；其余命令都在核心包的 flow.py 里
BOOT_COMMANDS = ("status", "setup", "guide", "upgrade", "consent")
# 引导器的 guide 只输出这段内置说明，不读任何文件，也不出现云端地址
BOOT_GUIDE = """# 即用创作小助手（待激活）

这台电脑上的即用创作小助手还没激活，现在只能做一件事：激活。
1. 向用户要商城订单编号（商城订单详情里的一串数字），用户已经在消息里给过就直接用。
2. 运行下面 STATUS / SAY / NEXT 里给出的 setup 命令，参数直接传用户原话。
3. 激活成功后完整的流程说明会自动下载，到时再运行一次 guide 查看。
不要修改脚本，也不要尝试绕过脚本做别的事。"""


def load_flow():
    """核心命令模块：本机还没有核心包（引导器）时返回 None。flow.py 在但导入出错时照常抛出"""
    if not (HERE / "flow.py").is_file():
        return None
    import flow
    return flow


# 补全核心包的超时：引导模式下每条命令都会先试一次，版本信息请求要快，连不上就跳过
CORE_CHECK_TIMEOUT = 3
CORE_DOWNLOAD_TIMEOUT = 60


def reexec(argv):
    """用 HOME/app 里刚装好的完整版重新执行一条命令，不再返回：execve 替换当前进程（进程号不变）。
    CLIPFLOW_REEXEC 防止新进程再次补全或升级"""
    script = HOME / "app" / "scripts" / "clipflow.py"
    env = dict(os.environ, CLIPFLOW_REEXEC=str(os.getpid()), CLIPFLOW_HOME=str(HOME))
    args = [sys.executable, str(script), *[str(x) for x in argv]]
    sys.stdout.flush()
    sys.stderr.flush()
    os.execve(sys.executable, args, env)


def fetch_core(server_url: str, cred: Credential, latest_timeout=30, package_timeout=CORE_DOWNLOAD_TIMEOUT):
    """补全 / 更新核心包，返回装上的版本号（已是最新返回 None）。
    云端 401 按 handle_auth_error 处理：能自动恢复就换上新凭证再试，订单失效等情况直接结束；
    网络、校验、安装失败照常抛出（MCPError / updater.UpdateError），由调用方决定怎么说"""
    holder = MCPClient(server_url, credential=cred)  # 只用来承载凭证，handle_auth_error 会换上新凭证
    while True:
        try:
            return updater.fetch_core(server_url, holder.credential, HOME, latest_timeout=latest_timeout,
                                      package_timeout=package_timeout)
        except AuthError as e:
            handle_auth_error(holder, e)


def _core_ready() -> bool:
    return (HOME / "app" / "scripts" / "flow.py").is_file()


def complete_core(argv):
    """引导模式（本机没有 flow.py）：已激活但还没有核心包时先补全一次，成功就用完整版重新执行当前命令。
    补全不了（网络、校验失败，或另一个进程正在安装）时只记一笔，回到原来的 need_order / core_missing"""
    if os.environ.get("CLIPFLOW_REEXEC"):
        return
    cfg = load_config()
    if not (cfg.get("server_url") and cfg.get("order_no") and cfg.get("kid")):
        return
    try:
        fetch_core(cfg["server_url"], credential(cfg), latest_timeout=CORE_CHECK_TIMEOUT)
    except (updater.UpdateError, MCPError) as e:
        log(f"[{now()}] 完整功能暂时没下载成功：{str(e)[:200]}")
        return
    if _core_ready():
        reexec(argv)


# ── 自动升级 ────────────────────────────────────────
# 完整版每条命令开头检查一次（guide / upgrade / setup 除外）：1 小时内检查过就跳过，版本信息请求 3 秒超时
# （CORE_CHECK_TIMEOUT）。任何失败都只在 update.json 里记一笔（failed_at / last_error），不在输出里提，
# 照常执行当前命令；失败后 UPGRADE_RETRY_AFTER 秒内不再检查，云端连不上时不会每条命令都多等 3 秒
UPGRADE_INTERVAL = 3600
UPGRADE_RETRY_AFTER = 10 * 60
# _job：后台作业进程（由前台命令启动），升级、同步都留给前台命令
NO_AUTO_UPGRADE = ("guide", "upgrade", "setup", "_job")


def _running_installed() -> bool:
    """当前运行的就是 HOME/app 里装好的那份。开发时直接跑源码目录不自动升级，免得被换成线上版本"""
    try:
        return HERE.resolve() == (HOME / "app" / "scripts").resolve()
    except OSError:
        return False


def _saved_credential(cfg):
    """本机已有的凭证（不重新激活）；没有时返回 None。设备标识读不到时 read_device_id 会 finish(device_unavailable)，
    调用方（自动升级、补丁回传）都把异常连同 Finish 一起吞掉，交给当前命令自己的云端调用再报"""
    cred = _SESSION["credential"]
    if cred is not None:
        return cred
    kid = cfg.get("kid", "")
    secret = device.load_secret(HOME) if kid else ""
    if not (kid and secret):
        return None
    cred = Credential(kid, secret, read_device_id())
    _SESSION["credential"] = cred
    return cred


def _recent(st: dict, key: str, interval: int) -> bool:
    """update.json 里的时间点在 interval 秒以内（时间点在未来，即系统时间被往回调过，不算）"""
    t = st.get(key)
    if not isinstance(t, (int, float)) or isinstance(t, bool):
        return False
    return 0 <= time.time() - t < interval


def _check_due() -> bool:
    st = updater.read_state(HOME)
    return not (_recent(st, "checked_at", UPGRADE_INTERVAL) or _recent(st, "failed_at", UPGRADE_RETRY_AFTER))


def _record_failure(e: BaseException):
    """自动检查没成功：记进 update.json 用于退避和排障，不打印（STATUS 前的输出大模型也会看到，免得误以为出了问题）"""
    try:
        updater.write_state(HOME, failed_at=int(time.time()),
                            last_error=f"{type(e).__name__}: {str(e)[:200]}")
    except Exception:  # noqa: BLE001  记不下来也不影响当前命令
        pass


def auto_upgrade(argv):
    """完整版、已激活时的定期升级：有新版就装上，再用新版重新执行当前命令（不再返回）。
    检查不到、校验不过、另一个进程正在安装、Python 版本不够……都只记进 update.json，照常执行当前命令。
    云端 401 / 426 在这里一律忽略，交给当前命令自己的云端调用处理（避免一条命令里重新激活两次）"""
    try:
        cfg = load_config()
        if not (cfg.get("server_url") and cfg.get("order_no") and cfg.get("kid")):
            return
        if not _check_due():
            return
        cred = _saved_credential(cfg)
        if cred is None:
            return
        new = updater.fetch_core(cfg["server_url"], cred, HOME, latest_timeout=CORE_CHECK_TIMEOUT,
                                 package_timeout=CORE_DOWNLOAD_TIMEOUT)
    except Exception as e:  # noqa: BLE001  这里出任何问题都不能影响当前命令（Finish 也一并吞掉）
        _record_failure(e)
        return
    if new:
        log(f"[{now()}] 即用创作小助手已自动更新到 {new}")
        reexec(argv)


def install_cmd() -> str:
    """重新安装引导器的命令：defaults.json 的 install_cmd（解释器后面的参数，release.py build 时填入）。
    没填（还没配置分发仓库）时返回空串"""
    args = read_json(HERE / "defaults.json", {}).get("install_cmd")
    if isinstance(args, list) and args and all(isinstance(x, str) and x for x in args):
        return _cmdline([sys.executable, *args])
    return ""


def _skill_outdated(e: SkillOutdated):
    """云端要求更高的版本（HTTP 426）。完整版：立即升级（每次运行最多一次），装上更新的版本就重新执行当前命令；
    升级不了就结束。引导器（激活时被拒），或本机从没激活过（拿不到核心包）：让 agent 重新运行安装命令，
    从分发仓库取最新的引导器"""
    argv = _SESSION.get("argv") or sys.argv[1:]
    retry = cmd(*argv) if argv else cmd("status")
    cfg = load_config()
    if load_flow() is None or not (cfg.get("order_no") and cfg.get("kid")):
        ic = install_cmd()
        how = (f"重新运行安装命令：{ic}（当初安装时带了 --skills-dir 或 --upload-zip 的话加上同样的参数；"
               "Skill 入口 SKILL.md 末尾也写着这条命令）") if ic else \
            "重新运行最初的安装命令（Skill 入口 SKILL.md 末尾写着）"
        finish("skill_outdated", "即用创作小助手需要更新一下，我马上重新安装。",
               f"本机的即用创作小助手版本太旧，云端不再接受。{how}；装好后再运行：{retry}", 1)
    why = f"云端要求 {e.min_version} 以上的版本" if e.min_version else "云端要求更新的版本"
    if not _SESSION.get("forced_upgrade"):
        _SESSION["forced_upgrade"] = True
        log(f"[{now()}] {why}，正在更新即用创作小助手")
        try:
            new = fetch_core(cfg.get("server_url", ""), credential(cfg))
        except updater.PythonTooOld as err:
            _python_too_old(err, retry, "skill_outdated")
        except (updater.UpdateError, MCPError) as err:
            why += f"，更新失败：{str(err)[:200]}"
        else:
            if new:
                log(f"[{now()}] 即用创作小助手已更新到 {new}")
                reexec(argv)
            why += f"，云端暂时还没有比 {updater.local_version(HOME) or '本机'} 更新的版本"
    finish("skill_outdated", "即用创作小助手需要更新，暂时没更新成功，请稍后再试；一直不行请联系即用客服。",
           f"过几分钟重新运行：{retry}（{why}）", 1)


def _python_too_old(err, retry, status="upgrade_failed"):
    """新版本要求更高的 Python：由 agent 直接升级，脚本不自己装"""
    ic = install_cmd()
    again = (f"用新装的 Python 重新运行安装命令（把命令开头的解释器换成新 Python）：{ic}"
             if ic else "用新装的 Python 重新运行最初的安装命令（Skill 入口 SKILL.md 末尾写着）")
    finish(status, "即用创作小助手的新版本需要先升级电脑上的一个基础工具，我这就帮你升级～",
           f"新版本要求 Python {err.required} 以上（当前 {sys.version_info[0]}.{sys.version_info[1]}）。"
           f"安装新版 Python，再{again}，最后重新运行：{retry}", 1)


def _core_unavailable(argv=()):
    """本机只有引导器：没激活就要订单号；已激活说明核心功能还没下载好，先补全"""
    if not load_config().get("order_no"):
        need_order()
    retry = cmd(*argv) if argv else cmd("status")
    finish("core_missing", "即用创作小助手的完整功能还没下载好，我先补全一下，稍等～",
           f"运行 {cmd('upgrade')} 补全完整功能，成功后重新运行：{retry}", 1)


# ── status / setup / guide / upgrade ────────────────
def cmd_status(a):
    cfg = load_config()
    log(f"云端服务：{'已配置' if cfg.get('server_url') else '（未配置）'}")  # 地址不对用户展示
    log(f"订单号：{mask(cfg['order_no']) if cfg.get('order_no') else '（未激活）'}")
    if cfg.get("order_no"):
        log(f"本机激活：{'已完成' if cfg.get('kid') else '待完成（下次连接云端时自动激活）'}")
    if not cfg.get("order_no"):
        need_order()
    fl = load_flow()
    if fl is None:
        _core_unavailable(["status", *(["--task", a.task] if a.task else [])])
    fl.status_tail(a, cfg)


def cmd_setup(a):
    cfg = load_config()
    order = parse_order(a.order) if a.order else cfg.get("order_no", "")
    server = normalize_url(a.server) if a.server else cfg.get("server_url", "")
    if not order:
        need_order()
    if not server:
        finish("need_server", "", "需要云端服务地址：加参数 --server http://服务器IP:8300", 1)
    retry = cmd("setup", "--order", order, *(["--server", a.server] if a.server else []))
    if a.resume:
        _setup_resume()
    # 本机只保存一个订单的凭证：换订单就是重新激活，覆盖旧的 kid 和密钥
    _SESSION["reactivated"] = True  # setup 本身就是激活，之后的 401 不再自动重新激活
    cred = activate_device(server, order, retry)
    # 地址只在显式传入时写入本机配置，否则一直跟随 defaults.json（即用客服改地址后用户无需重配）
    save_user_config(**({"server_url": server} if a.server else {}))
    order = user_config().get("order_no") or order
    c = MCPClient(server, credential=cred, timeout=30)
    try:
        tools = c.list_tools()
    except AuthError as e:
        handle_auth_error(c, e)
    except SkillOutdated as e:
        _skill_outdated(e)
    except (ConnectError, MCPError) as e:
        finish("network_error", "暂时连不上剪辑服务，请检查网络后再试。",
               f"网络恢复后重新运行：{retry}（错误：{str(e)[:200]}）", 1)
    names = {t.get("name") for t in tools}
    log(f"订单号 {mask(order)} 激活成功，云端工具 {len(names & CLOUD_TOOLS)}/{len(CLOUD_TOOLS)} 个可用")
    missing = CLOUD_TOOLS - names
    if missing:
        log(f"注意：云端缺少工具 {sorted(missing)}，流程可能受影响")
    fl = load_flow()
    if fl is None:
        # 本机只有引导器：激活成功后马上补全核心包，再用完整版接着走 setup 的后半段
        try:
            fetch_core(server, c.credential)
        except (updater.UpdateError, MCPError) as e:
            finish("core_missing", "激活成功！还有一部分内容没下载完，我稍后再试一下～",
                   f"稍后运行：{cmd('upgrade')}，成功后运行：{cmd('guide')}（错误：{str(e)[:200]}）", 1)
        if not _core_ready():
            finish("core_missing", "激活成功！还有一部分内容没下载完，我稍后再试一下～",
                   f"稍后运行：{cmd('upgrade')}，成功后运行：{cmd('guide')}", 1)
        reexec(["setup", "--resume"])
    fl.after_setup()


def _setup_resume():
    """setup --resume：激活和补全核心包已经完成（由引导器重新执行过来），直接走后半段"""
    cfg = load_config()
    if not (cfg.get("order_no") and cfg.get("kid")):
        need_order()
    fl = load_flow()
    if fl is None:
        _core_unavailable(["setup", "--resume"])
    log(f"订单号 {mask(cfg['order_no'])} 激活成功，完整功能已下载")
    fl.after_setup()


def cmd_guide(a):
    """每次使用先运行：完整版由 flow 打印完整流程说明；引导器只打印内置的激活说明。之后都接着执行 status"""
    fl = load_flow()
    if fl is None:
        log(BOOT_GUIDE)
        log("")
    else:
        fl.print_guide()
    cmd_status(a)


def cmd_upgrade(a):
    """立即检查并补全 / 升级核心包：upgraded（装上了新版或补全了核心包）/ up_to_date / upgrade_failed"""
    cfg = load_config()
    if not cfg.get("order_no"):
        need_order()
    old = updater.local_version(HOME) or "（无）"
    try:
        new = fetch_core(cfg.get("server_url", ""), credential(cfg))
    except updater.PythonTooOld as e:
        _python_too_old(e, cmd("guide"))
    except updater.LockBusy:
        finish("upgrade_failed", "即用创作小助手正在更新，稍等一会儿～",
               f"另一个命令正在安装，等半分钟后重新运行：{cmd('upgrade')}", 1)
    except (updater.UpdateError, MCPError) as e:
        finish("upgrade_failed", "即用创作小助手暂时没更新成功，我稍后再试；一直不行请联系即用客服。",
               f"稍后重新运行：{cmd('upgrade')}（错误：{str(e)[:200]}）", 1)
    if new is None:
        finish("up_to_date", "", f"已是最新版本 {old}。接着运行：{cmd('guide')}")
    log(f"即用创作小助手已更新：{old} → {new}")
    finish("upgraded", "", f"已更新到 {new}。接着运行：{cmd('guide')}，或重新运行刚才没成功的命令")


# ── 入口 ────────────────────────────────────────────
def add_note(say="", nxt=""):
    """命令开头顺带做了用户 / agent 该知道的事（例如发布助手刚自动更新过）：
    say 拼在本条命令最终 SAY 的前面，nxt 拼在 NEXT 的后面。同样的话只加一次"""
    for key, text in (("say_notes", say), ("next_notes", nxt)):
        notes = _SESSION.setdefault(key, [])
        if text and text not in notes:
            notes.append(text)


def _flat(text: str) -> str:
    """三行协议各占一行：错误原文（ffmpeg、lark-cli 的输出）里的换行压成空格"""
    return re.sub(r"\s*\n\s*", " ", text or "").strip()


def _emit(f: Finish) -> int:
    say = _flat(" ".join(x for x in [*_SESSION.get("say_notes", []), f.say] if x))
    nxt = f.nxt
    extra = _SESSION.get("next_notes") or []
    if extra:
        nxt = (nxt.rstrip("。；; ") + "。另外：" if nxt else "") + "；".join(extra)
    nxt = _flat(nxt)
    log("")
    log(f"STATUS: {f.status}")
    log(f"SAY: {say or '（无）'}")
    log(f"NEXT: {nxt or '（无）'}")
    return f.code


# 不在开头同步发布助手的命令：guide 每次使用先跑，要快；setup / upgrade 之后的下一条命令会同步；
# install-publisher 自己就会部署；sms-send / sms-verify / phone-login 正处在身份验证、手机号登录中，这时不换代码
# （有活着的会话时 sync 本来也会跳过，这里再保险一道）；check-env 只管剪辑环境，不碰发布助手；consent 只记一笔
NO_PUBLISHER_SYNC = NO_AUTO_UPGRADE + ("install-publisher", "phone-login", "sms-send", "sms-verify", "check-env",
                                       "consent")


def _jobs_running(fl) -> bool:
    """有后台作业在跑时这次不检查升级（不记失败，下一条命令再查）：作业还要从 app/ 里启动脚本。
    查不了就当没有，不能因为这一步出错一直不升级"""
    check = getattr(fl, "jobs_running", None)
    try:
        return bool(check and check())
    except Exception:  # noqa: BLE001
        return False


def _refresh_entry():
    """完整版命令开头、本体升级检查之后：把技能库里我们写的入口 SKILL.md 换成新版模板（显示名、描述随版本更新）。
    app/entry/SKILL.md 的 sha256 和 update.json 的 entry_sha 一样就跳过（每条命令只多读一个小文件）；
    成功才记 entry_sha，写不进去的下一条命令再试。出任何问题都只记进 update.json（entry_error），不打印，照常执行当前命令"""
    try:
        app = HOME / "app"
        sha = hashlib.sha256((app / "entry" / "SKILL.md").read_bytes()).hexdigest()
        if updater.read_state(HOME).get("entry_sha") == sha:
            return
        import install  # 引导包里的安装器，只在入口模板变了的这一次才导入
        install.refresh_entries(app, install_cmd())
        updater.write_state(HOME, entry_sha=sha, entry_error=None)
    except Exception as e:  # noqa: BLE001  Finish 也一并吞掉
        try:
            updater.write_state(HOME, entry_error=f"{type(e).__name__}: {str(e)[:200]}")
        except Exception:  # noqa: BLE001
            pass


def _sync_publisher(fl):
    """完整版命令开头、本体升级检查之后：让本机发布助手跟上定版代码（flow.publisher_sync）。
    出任何问题都只记进 update.json，照常执行当前命令"""
    sync = getattr(fl, "publisher_sync", None)
    if sync is None:
        return
    try:
        sync()
    except Exception as e:  # noqa: BLE001  Finish 也一并吞掉
        try:
            updater.write_state(HOME, publisher_error=f"{type(e).__name__}: {str(e)[:200]}")
        except Exception:  # noqa: BLE001
            pass


def _upload_patches(fl):
    """完整版命令开头、发布助手同步之后：回传本机发布助手的临时补丁（flow.patch_upload）。
    和自动升级一样只走 updater / mcp_client，不经过 call()：401 / 426 不重新激活、不清理核心文件，
    交给当前命令自己的云端调用处理。出任何问题都只记进 update.json（10 分钟内不再试），照常执行当前命令"""
    up = getattr(fl, "patch_upload", None)
    if up is None:
        return
    try:
        up()
    except Exception as e:  # noqa: BLE001  Finish 也一并吞掉
        try:
            updater.write_state(HOME, patches_failed_at=int(time.time()),
                                patches_error=f"{type(e).__name__}: {str(e)[:200]}")
        except Exception:  # noqa: BLE001
            pass


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    ap = argparse.ArgumentParser(description="即用创作小助手 短剧推广")

    def usage_error(message):
        log(f"参数错误：{message}")
        log("")
        log("STATUS: usage_error")
        log("SAY: （无）")
        log(f"NEXT: 查看用法：{cmd('--help')}")
        sys.exit(2)

    ap.error = usage_error
    sub = ap.add_subparsers(dest="command", required=True)

    def add(name, fn, task=True):
        p = sub.add_parser(name)
        p.set_defaults(fn=fn)
        p.error = ap.error
        if task:
            p.add_argument("--task", default="", help="任务名（省略=最近一次任务）")
        p.add_argument("--max-wait", type=int, default=DEFAULT_WAIT,
                       help="等待类命令本次最多等待的秒数（其他命令忽略）")
        return p

    add("guide", cmd_guide)
    add("status", cmd_status)
    p = add("setup", cmd_setup, task=False)
    p.add_argument("--order", default="", help="商城订单编号（可直接传用户原话）")
    p.add_argument("--server", default="", help="云端服务地址，如 http://1.2.3.4:8300")
    p.add_argument("--resume", action="store_true", help=argparse.SUPPRESS)  # 引导器补全核心包后重新执行用
    add("upgrade", cmd_upgrade, task=False)
    p = add("consent", cmd_consent, task=False)
    p.add_argument("--agree", action="store_true", help="用户已明确回复同意用户服务协议")

    _SESSION.update(argv=list(argv), forced_upgrade=False, say_notes=[], next_notes=[], announced=False)
    try:
        require_doubao()  # 每条命令的第一件事：在清理残留、自动升级之前，不是豆包云电脑就什么都不写
    except Finish as f:
        return _emit(f)
    try:
        updater.recover(HOME)  # 上次升级到一半崩了：恢复成完整的一个版本；删不掉的留到下次
    except Exception as e:  # noqa: BLE001
        log(f"[{now()}] 清理上次没装完的文件失败：{str(e)[:200]}")

    try:
        fl = load_flow()
        if fl is not None:
            fl.register(sub, add)
        elif argv and not argv[0].startswith("-"):
            if argv[0] not in ("setup", "upgrade"):  # 这两条命令自己会补全核心包
                complete_core(argv)
            if argv[0] not in BOOT_COMMANDS:
                # 引导器不认识核心命令：不交给 argparse（会报 usage_error），统一按「核心包不在」处理
                _core_unavailable(argv)
        a = ap.parse_args(argv)
        if fl is not None and _running_installed():
            if a.command not in NO_AUTO_UPGRADE and not os.environ.get("CLIPFLOW_REEXEC") and not _jobs_running(fl):
                auto_upgrade(argv)
            if a.command != "_job":
                _refresh_entry()
            if a.command not in NO_PUBLISHER_SYNC:
                _sync_publisher(fl)
            if a.command not in NO_AUTO_UPGRADE:
                _upload_patches(fl)
        # 用户服务协议门禁（设计 6.2）：老用户可能在任何一步升级，默认都拦，只放行 CONSENT_FREE。
        # 放在自动升级之后：用新版的门禁和文字；引导器（还没有核心包）只能激活，不用拦
        if fl is not None and a.command not in CONSENT_FREE:
            require_consent()
        a.fn(a)
        raise Finish("ok")
    except Finish as f:
        return _emit(f)
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())

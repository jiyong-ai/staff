"""极简 MCP 客户端（streamable HTTP，仅用 Python 标准库）

让脚本直接调用课程云端的 MCP，轮询、编排都在代码里完成，不必每一步都经过大模型。
（本机的抖音发布助手不走网络，见 pubclient.py。）

用法:
    cred = Credential(kid, secret, device_id)          # 云端：激活后拿到的设备凭证，每个请求签名
    c = MCPClient("http://host:8300/mcp/", credential=cred)
    c.call_tool("get_material_status", {"task_name": "xxx"})
    signed_get(server_url, "/api/v1/skill/latest", cred)  # 云端 REST：带签名 GET（核心包版本信息和下载）
    signed_post(server_url, "/api/v1/publisher/patches", cred, {...})  # 云端 REST：带签名 POST JSON（补丁回传）

云端签名协议（与 clipflow 云端 app/device_sign.py 一致，tests/vectors/device_sign_v1.json 交叉验证）：
  签名串 = "\\n".join(["clipflow-v1", METHOD, RAW_PATH, RAW_QUERY, kid, device_id, ts, nonce, sha256_hex(body)])
  X-Clip-Sign = base64url(HMAC-SHA256(secret 字符串的 UTF-8 字节, 签名串))，不带 "=" 填充
  METHOD 大写；RAW_PATH 是百分号编码的原始路径（不含 query）；RAW_QUERY 不含 "?"

版本头：所有请求（MCP、激活、签名 GET / POST）都带 X-Clip-Version: <本机 VERSION>，它不进签名串。
云端要求更高的版本时返回 HTTP 426 {"error": "skill_outdated", "min_version": "..."}，这里抛 SkillOutdated。
"""
import base64
import hashlib
import hmac
import itertools
import json
import re
import secrets
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

PROTOCOL_VERSION = "2025-06-18"
SIGN_VERSION = "clipflow-v1"
ACTIVATE_PATH = "/api/v1/devices/activate"
VERSION_HEADER = "X-Clip-Version"


def _read_version() -> str:
    """本机版本号：<scripts>/../VERSION。读不到、或不是「主.次.修订」（源码里的 0.0.0-dev）时按 0.0.0"""
    try:
        v = (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        return "0.0.0"
    return v if re.fullmatch(r"\d+\.\d+\.\d+", v) else "0.0.0"


# 每个请求都带的版本头（不进签名串）。升级后会重新执行命令，导入时读一次就够
CLIENT_VERSION = _read_version()

# 本进程与云端的时钟差（秒）。clock_skew 时按服务端时间修正，进程内所有客户端共用
_CLOCK = {"offset": 0}


class MCPError(Exception):
    """协议/服务端错误"""


class AuthError(MCPError):
    """401：设备凭证无效、已解绑、订单失效等。code 为云端返回的错误码（旧版云端没有时为空串）"""

    def __init__(self, code: str = "", message: str = "", server_time=None):
        super().__init__(message or code or "401 Unauthorized")
        self.code = code or ""
        self.server_time = server_time


class ActivateError(MCPError):
    """激活失败。code 为云端错误码（other_device / order_invalid / activate_limited …），
    status 为订单状态（仅 order_invalid 时有），http_status 为 HTTP 状态码"""

    def __init__(self, code: str, message: str = "", status: str = "", http_status: int = 0):
        super().__init__(message or code or f"HTTP {http_status}")
        self.code = code or ""
        self.status = status or ""
        self.http_status = http_status


class ConnectError(MCPError):
    """连不上服务（网络不通、服务未启动、超时）"""


class ToolError(MCPError):
    """工具执行报错（isError=true）"""


class SkillOutdated(MCPError):
    """426：云端要求更高的版本（skill_outdated）。min_version 为云端给出的最低版本（可能为空）"""

    def __init__(self, min_version: str = "", message: str = ""):
        super().__init__(message or f"skill_outdated（最低版本 {min_version or '未知'}）")
        self.min_version = min_version or ""


def _outdated(body: str) -> SkillOutdated:
    obj = _err_obj(body)
    return SkillOutdated(str(obj.get("min_version") or ""), _err_text(body)[:300])


def _version_headers() -> dict:
    return {VERSION_HEADER: CLIENT_VERSION}


def _err_obj(body: str) -> dict:
    try:
        obj = json.loads(body)
    except ValueError:
        return {}
    return obj if isinstance(obj, dict) else {}


def _err_text(body: str) -> str:
    obj = _err_obj(body)
    if obj:
        return str(obj.get("error") or obj.get("message") or obj.get("detail") or body)
    return body


# ── 设备凭证签名 ─────────────────────────────────────
@dataclass(frozen=True)
class Credential:
    """云端设备凭证。secret 不参与 repr，避免出现在日志和报错里"""
    kid: str
    secret: str = field(repr=False)
    device_id: str = field(repr=False)


def _b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def canonical_string(method: str, raw_path: str, raw_query: str, kid: str, device_id: str,
                     ts, nonce: str, body: bytes) -> str:
    return "\n".join([SIGN_VERSION, method.upper(), raw_path, raw_query or "", kid, device_id,
                      str(ts), nonce, hashlib.sha256(body or b"").hexdigest()])


def sign(secret: str, canonical: str) -> str:
    return _b64url(hmac.new(secret.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).digest())


def raw_path_query(url: str):
    """请求行里实际发送的路径与 query（urllib 原样发送，不再编码）"""
    parts = urlsplit(url)
    return parts.path or "/", parts.query


def sign_headers(cred: Credential, method: str, url: str, body: bytes, ts=None, nonce=None) -> dict:
    """生成 5 个签名头。ts 默认取本机时间 + 时钟修正；nonce 默认每次随机"""
    ts = str(int(time.time()) + _CLOCK["offset"] if ts is None else ts)
    nonce = nonce or secrets.token_hex(16)
    path, query = raw_path_query(url)
    canonical = canonical_string(method, path, query, cred.kid, cred.device_id, ts, nonce, body)
    return {"X-Clip-Kid": cred.kid, "X-Clip-Device": cred.device_id, "X-Clip-Ts": ts,
            "X-Clip-Nonce": nonce, "X-Clip-Sign": sign(cred.secret, canonical)}


def api_url(server_url: str, path: str) -> str:
    """由 MCP 地址推出云端 REST 地址：去掉末尾的 /mcp/，再拼上 path（以 / 开头）"""
    parts = urlsplit(normalize_url(server_url))
    root = parts.path.rstrip("/")
    if root.endswith("/mcp"):
        root = root[:-len("/mcp")]
    return urlunsplit((parts.scheme, parts.netloc, root + path, "", ""))


def activate_url(server_url: str) -> str:
    """由 MCP 地址推出激活地址：去掉末尾的 /mcp/，拼 /api/v1/devices/activate"""
    return api_url(server_url, ACTIVATE_PATH)


def _opener():
    # 直连，不走系统代理：学员电脑常开代理软件，会拦截发往公网 IP 的请求
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def activate(server_url: str, order_no: str, device_id: str, timeout: float = 30) -> dict:
    """POST 激活接口，成功返回 {"kid", "secret", "order_no"(云端规范化后的订单号)}。
    失败抛 ActivateError（云端拒绝）或 ConnectError（网络不通）"""
    data = json.dumps({"order_no": order_no, "device_id": device_id}).encode("utf-8")
    headers = {"Content-Type": "application/json", "Accept": "application/json", **_version_headers()}
    req = urllib.request.Request(activate_url(server_url), data=data, method="POST", headers=headers)
    try:
        resp = _opener().open(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        if e.code == 426:
            raise _outdated(body)
        obj = _err_obj(body)
        raise ActivateError(str(obj.get("code") or ""), _err_text(body)[:300] or f"HTTP {e.code}",
                            str(obj.get("status") or ""), e.code)
    except (urllib.error.URLError, socket.timeout, ConnectionError, OSError) as e:
        raise ConnectError(str(getattr(e, "reason", e)))
    with resp:
        try:
            raw = resp.read().decode("utf-8", "replace")
        except (socket.timeout, OSError) as e:
            raise ConnectError(f"读取响应超时：{e}")
    obj = _err_obj(raw)
    kid, secret = str(obj.get("kid") or ""), str(obj.get("secret") or "")
    if not kid or not secret:
        raise ActivateError("", "激活响应缺少凭证", http_status=200)
    return {"kid": kid, "secret": secret, "order_no": str(obj.get("order_no") or order_no)}


def _auth_error(body: str) -> AuthError:
    obj = _err_obj(body)
    server_time = obj.get("server_time")
    return AuthError(str(obj.get("code") or ""), _err_text(body)[:300] or "401 Unauthorized",
                     server_time if isinstance(server_time, (int, float)) else None)


def _signed_once(method: str, url: str, cred: Credential, body: bytes, timeout: float) -> bytes:
    headers = {"Accept": "application/json, application/zip", **_version_headers()}
    if method == "POST":
        headers["Content-Type"] = "application/json"
    headers.update(sign_headers(cred, method, url, body))
    req = urllib.request.Request(url, data=body if method == "POST" else None, headers=headers, method=method)
    try:
        resp = _opener().open(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        if e.code == 401:
            raise _auth_error(body)
        if e.code == 426:
            raise _outdated(body)
        raise MCPError(f"HTTP {e.code}: {_err_text(body)[:300]}")
    except (urllib.error.URLError, socket.timeout, ConnectionError, OSError) as e:
        raise ConnectError(str(getattr(e, "reason", e)))
    with resp:
        try:
            return resp.read()
        except (socket.timeout, OSError) as e:
            raise ConnectError(f"读取响应超时：{e}")


def signed_get(server_url: str, path: str, cred: Credential, timeout: float = 30) -> bytes:
    """带设备签名 GET 云端 REST 接口（核心包的版本信息和下载），返回响应体原始字节。
    401 抛 AuthError（clock_skew 按服务端时间修正、replayed 换 nonce，各自动重试一次），426 抛 SkillOutdated，
    其他 HTTP 错误抛 MCPError，网络不通抛 ConnectError。直连，不走系统代理"""
    return _signed("GET", api_url(server_url, path), cred, b"", timeout)


def signed_post(server_url: str, path: str, cred: Credential, payload: dict, timeout: float = 30) -> bytes:
    """带设备签名 POST JSON 到云端 REST 接口（发布助手补丁回传），返回响应体原始字节。
    错误映射和自动重试同 signed_get"""
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return _signed("POST", api_url(server_url, path), cred, body, timeout)


def _signed(method: str, url: str, cred: Credential, body: bytes, timeout: float) -> bytes:
    retried = set()
    while True:
        try:
            return _signed_once(method, url, cred, body, timeout)
        except AuthError as e:
            if e.code in retried:
                raise
            if e.code == "clock_skew" and isinstance(e.server_time, (int, float)):
                _CLOCK["offset"] = int(e.server_time) - int(time.time())
            elif e.code != "replayed":
                raise
            retried.add(e.code)


def _parse_messages(ctype: str, raw: str) -> list:
    """响应体可能是 application/json，也可能是 SSE（text/event-stream）"""
    if "text/event-stream" in ctype:
        chunks, data = [], []
        for line in raw.splitlines():
            if line.startswith("data:"):
                data.append(line[5:].lstrip())
            elif not line.strip() and data:
                chunks.append("\n".join(data))
                data = []
        if data:
            chunks.append("\n".join(data))
        out = []
        for c in chunks:
            try:
                out.append(json.loads(c))
            except ValueError:
                pass
        return out
    raw = raw.strip()
    if not raw:
        return []
    obj = json.loads(raw)
    return obj if isinstance(obj, list) else [obj]


def parse_tool_result(res: dict):
    """tools/call 结果 → Python 对象（dict 优先；纯文本工具返回 str）"""
    texts = [c.get("text", "") for c in res.get("content") or [] if c.get("type") == "text"]
    text = "\n".join(texts).strip()
    if res.get("isError"):
        raise ToolError(text or "工具执行失败")
    sc = res.get("structuredContent")
    if isinstance(sc, dict) and sc:
        if set(sc) == {"result"}:
            return sc["result"]
        return sc
    if text:
        try:
            return json.loads(text)
        except ValueError:
            return text
    return {}


def normalize_url(url: str) -> str:
    """补全 MCP 端点：http://host:8300 → http://host:8300/mcp/（POST 不跟随 307，必须带尾斜杠）"""
    url = (url or "").strip()
    if not url:
        return url
    if "://" not in url:
        url = "http://" + url
    scheme, rest = url.split("://", 1)
    if "/" not in rest:
        return f"{scheme}://{rest}/mcp/"
    if not url.endswith("/"):
        url += "/"
    return url


class MCPClient:
    def __init__(self, url: str, credential: Credential = None, timeout: float = 60):
        self.url = normalize_url(url)
        self.credential = credential  # None：不签名
        self.timeout = timeout
        self.session_id = None
        self.protocol = PROTOCOL_VERSION
        self.ready = False
        self._ids = itertools.count(1)
        self._opener = _opener()

    @property
    def clock_offset(self) -> int:
        return _CLOCK["offset"]

    @clock_offset.setter
    def clock_offset(self, value: int):
        _CLOCK["offset"] = int(value)

    # ── 底层 ────────────────────────────────────────
    def _post(self, payload: dict, timeout=None):
        """发送一次请求。clock_skew 按服务端时间修正后重试一次；replayed 换 nonce 重试一次"""
        data = json.dumps(payload).encode("utf-8")
        retried = set()
        while True:
            try:
                return self._send(data, timeout)
            except AuthError as e:
                if not self.credential or e.code in retried:
                    raise
                if e.code == "clock_skew" and isinstance(e.server_time, (int, float)):
                    self.clock_offset = int(e.server_time) - int(time.time())
                elif e.code != "replayed":
                    raise
                retried.add(e.code)

    def _send(self, data: bytes, timeout=None):
        headers = {"Content-Type": "application/json",
                   "Accept": "application/json, text/event-stream", **_version_headers()}
        if self.credential:
            headers.update(sign_headers(self.credential, "POST", self.url, data))
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
        if self.ready:
            headers["MCP-Protocol-Version"] = self.protocol
        req = urllib.request.Request(self.url, data=data, headers=headers, method="POST")
        try:
            resp = self._opener.open(req, timeout=timeout or self.timeout)
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")
            if e.code == 401:
                raise _auth_error(body)
            if e.code == 426:
                raise _outdated(body)
            if e.code == 404 and self.session_id:
                raise _SessionExpired(body)
            raise MCPError(f"HTTP {e.code}: {_err_text(body)[:300]}")
        except (urllib.error.URLError, socket.timeout, ConnectionError, OSError) as e:
            raise ConnectError(str(getattr(e, "reason", e)))
        with resp:
            sid = resp.headers.get("mcp-session-id")
            if sid:
                self.session_id = sid
            ctype = resp.headers.get("Content-Type", "")
            try:
                raw = resp.read().decode("utf-8", "replace")
            except (socket.timeout, OSError) as e:
                raise ConnectError(f"读取响应超时：{e}")
        return ctype, raw

    def _request(self, method: str, params: dict, timeout=None):
        rid = next(self._ids)
        ctype, raw = self._post({"jsonrpc": "2.0", "id": rid, "method": method,
                                 "params": params}, timeout)
        try:
            msgs = _parse_messages(ctype, raw)
        except ValueError:
            raise MCPError(f"无法解析响应：{raw[:200]}")
        for m in msgs:
            if m.get("id") == rid:
                if "error" in m:
                    err = m["error"]
                    raise MCPError(err.get("message") if isinstance(err, dict) else str(err))
                return m.get("result") or {}
        raise MCPError(f"响应中没有找到结果：{raw[:200]}")

    def _notify(self, method: str):
        try:
            self._post({"jsonrpc": "2.0", "method": method})
        except MCPError:
            pass  # 通知失败不影响后续调用

    # ── 对外接口 ────────────────────────────────────
    def initialize(self):
        self.session_id, self.ready = None, False
        res = self._request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "short-drama-pipeline-skill", "version": CLIENT_VERSION},
        })
        self.protocol = res.get("protocolVersion") or PROTOCOL_VERSION
        self.ready = True
        self._notify("notifications/initialized")
        return res

    def list_tools(self) -> list:
        if not self.ready:
            self.initialize()
        return self._with_session(lambda: self._request("tools/list", {})).get("tools", [])

    def call_tool(self, name: str, arguments: dict = None, timeout=None):
        if not self.ready:
            self.initialize()
        res = self._with_session(
            lambda: self._request("tools/call", {"name": name, "arguments": arguments or {}}, timeout))
        return parse_tool_result(res)

    def _with_session(self, fn):
        """服务重启后旧会话失效（404），自动重新握手一次"""
        try:
            return fn()
        except _SessionExpired:
            self.initialize()
            return fn()


class _SessionExpired(MCPError):
    pass

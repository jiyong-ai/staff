"""本机设备标识与设备密钥存储（仅用 Python 标准库；只在豆包云电脑上运行）

豆包云电脑的 /etc/machine-id 是镜像里写死的，所有账号都一样，BROWSER_GROUP_ID 和家目录的存储 ID 同一账号换个会话
也会变，都不能当设备标识（docs/豆包云电脑专用版设计.md 第 2 节）。所以设备标识来自一个随机种子：

  第一次需要时用 secrets 生成 32 字节随机数，存到 <数据目录>/device.seed（0600）；以后一直沿用。
  device_id = "v1." + sha256_hex("clipflow-device-v1:doubao:" + seed)

家目录跟着豆包账号走：云电脑重启、新开会话后种子还在，设备标识不变；不同账号的种子不同。
已知限制：整个 ~/.clipflow 拷给别人，等于把设备克隆了一份，客户端防不住，防共享要靠云端。

只上传哈希，不上传种子。种子文件存在但内容不对时抛 DeviceUnavailable，不自动覆盖，免得悄悄变成另一台设备。
「不退回随机值」这条原则防的是每次运行临时生成新值；这里的随机值只生成一次、之后一直沿用，并不违背它。

设备密钥（激活时云端下发的 secret）存到 <数据目录>/device.key，权限 0600（明文：豆包上客户端能用的东西都在家目录里，
没有更安全的地方）。

本模块的任何输出、异常信息都不包含种子、设备标识或密钥。
"""
import hashlib
import os
import re
import secrets
import time
from pathlib import Path

import doubao_env

DEVICE_ID_VERSION = "v1"
_HASH_CONTEXT = "clipflow-device-v1:"
PLATFORM = "doubao"

SECRET_FILE = "device.key"
SEED_FILE = "device.seed"
_SEED_RE = re.compile(r"^[0-9a-f]{64}$")
_SEED_STALE = 10    # 同一个临时文件这么多秒一直没动（大小、修改时间、inode 都没变）：上次崩溃留下的，删掉重来
_SEED_OLD = 60      # 临时文件的修改时间比现在早这么多秒：一看就是残留，不用等
_SEED_WAIT = 30     # 等另一个进程生成种子最多这么多秒，还没好就报 DeviceUnavailable（下次运行再试）


class DeviceUnavailable(Exception):
    """读不到本机设备标识"""


class SecretStoreError(Exception):
    """设备密钥写入失败"""


def _platform() -> str:
    ok, _ = doubao_env.check()
    if not ok:
        # 入口、安装器、install-publisher 已经先拦下；走到这里说明有人绕过了入口
        raise DeviceUnavailable("不是豆包云电脑")
    return PLATFORM


# ── 设备标识 ─────────────────────────────────────────
def _read_seed(path: Path):
    """返回种子；文件不存在返回 None；内容不对抛 DeviceUnavailable（不覆盖）"""
    try:
        text = path.read_text(encoding="ascii")
    except FileNotFoundError:
        return None
    except (OSError, UnicodeDecodeError):
        raise DeviceUnavailable("读取设备种子失败") from None
    text = text.strip()
    if not _SEED_RE.match(text):
        raise DeviceUnavailable("设备种子文件的内容不对")
    return text


def _fsync_dir(d: Path):
    """改名落盘：目录也 fsync 一下（网络盘、个别文件系统不支持时忽略）"""
    try:
        fd = os.open(str(d), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _create_seed(path: Path) -> str:
    """O_CREAT|O_EXCL 建临时文件 → 写入 → 改名；并发时只有一个进程建成，另一个重新读取已有的种子。

    临时文件同时是「正在生成」的锁：拿不到时等持有者改名完成；只有确认是崩溃残留（_SEED_STALE 秒没动、
    或修改时间早于 _SEED_OLD 秒）才删掉重来，不按固定时间抢正在写的进程。
    返回值以改名后文件里的内容为准：万一残留判断错了、两个进程先后改名，返回的也总是当时落盘的那一份"""
    tmp = path.with_name(path.name + ".tmp")
    deadline = time.monotonic() + _SEED_WAIT
    watched = None   # (临时文件的 (inode, 大小, 修改时间), 开始观察的时刻)
    while True:
        try:
            fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            seed = _read_seed(path)
            if seed:
                return seed
            if time.monotonic() > deadline:
                raise DeviceUnavailable("另一个进程一直没生成完设备种子") from None
            try:
                st = tmp.stat()
            except OSError:
                continue  # 刚被持有者改名走了：下一轮重新读
            key = (st.st_ino, st.st_size, st.st_mtime_ns)
            if watched is None or watched[0] != key:
                watched = (key, time.monotonic())
            if time.time() - st.st_mtime > _SEED_OLD or time.monotonic() - watched[1] > _SEED_STALE:
                try:
                    tmp.unlink()
                except OSError:
                    pass
                watched = None
                continue
            time.sleep(0.02)
            continue
        published = False
        try:
            # 拿到临时文件后再看一眼：另一个进程可能刚好在我们检查之后建好了，不能覆盖它
            seed = _read_seed(path)
            if seed:
                return seed
            with os.fdopen(fd, "w", encoding="ascii") as f:
                fd = None
                f.write(secrets.token_hex(32))
                f.flush()
                os.fsync(f.fileno())   # 先落盘再改名：免得崩溃后留下一个改了名、内容却是空的种子（之后只能报错）
            os.replace(str(tmp), str(path))
            published = True
            os.chmod(str(path), 0o600)
            _fsync_dir(path.parent)
        finally:
            if fd is not None:
                os.close(fd)
            if not published:   # 改名成功后 tmp 这个名字已经不是我们的了，不能再删
                try:
                    tmp.unlink()
                except OSError:
                    pass
        seed = _read_seed(path)
        if not seed:
            raise DeviceUnavailable("设备种子写入后读不到")
        return seed


def _device_seed(home: Path) -> str:
    path = Path(home) / SEED_FILE
    try:
        seed = _read_seed(path)
        if seed is None:
            path.parent.mkdir(parents=True, exist_ok=True)
            seed = _create_seed(path)
    except DeviceUnavailable:
        raise
    except Exception as e:  # 目录没有写权限、磁盘满等
        raise DeviceUnavailable(f"生成设备种子失败（{type(e).__name__}）") from None
    return seed


def device_id(home) -> str:
    """本机设备标识（v1. + 64 位小写 hex）。读取失败抛 DeviceUnavailable

    home 是数据目录（种子文件所在）；设备标识不接受任何外部输入。"""
    platform = _platform()
    seed = _device_seed(Path(home))
    digest = hashlib.sha256(f"{_HASH_CONTEXT}{platform}:{seed}".encode("utf-8")).hexdigest()
    return f"{DEVICE_ID_VERSION}.{digest}"


# ── 设备密钥：<数据目录>/device.key，0600 ────────────
def _write_private(path: Path, text: str):
    """写 0600 文件：每个进程用自己的临时文件，写完落盘再改名（两个进程同时写时，最后改名的那份完整生效）"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.{os.getpid()}-{secrets.token_hex(4)}.tmp")
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="ascii") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp), str(path))
        os.chmod(str(path), 0o600)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise


def save_secret(secret: str, home: Path):
    """保存设备密钥。失败抛 SecretStoreError（调用方此时不要写入 kid）"""
    if not secret:
        raise SecretStoreError("设备密钥为空")
    try:
        _write_private(Path(home) / SECRET_FILE, secret)
    except Exception as e:
        raise SecretStoreError(f"设备密钥写入失败（{type(e).__name__}）") from None


def load_secret(home: Path) -> str:
    """读取设备密钥；没有或读不出时返回空串"""
    try:
        return (Path(home) / SECRET_FILE).read_text(encoding="ascii").strip()
    except Exception:
        return ""


def delete_secret(home: Path):
    try:
        (Path(home) / SECRET_FILE).unlink()
    except OSError:
        pass

"""识别豆包云电脑（只用 Python 3.8+ 标准库；引导包和核心包都有）

这个 Skill 只在豆包云电脑上运行（docs/豆包云电脑专用版设计.md 6.1）。判定规则，全部满足才算：
  1. Linux，x86_64；
  2. /opt/browser/chrome 是文件且可执行（平台自带的浏览器）；
  3. 环境变量 DOUBAO_SANDBOX_TYPE 不为空，或者 BROWSER_USER_AGENT 里含 DoubaoWorkVM。

环境变量谁都能伪造：这个检查只是为了挡住装错版本的人，不是安全措施。第 3 条用「或」，
平台以后改掉其中一个变量时，不至于把所有豆包学员都挡在外面。

install.py 是被 exec 运行的，没有 __file__，导入不了本模块，里面内联了同样的判定（_doubao_check）和文案；
tests/skill/test_doubao_env.py 用同一组用例测两处，保证一致。

check() 通过 platform.system() / platform.machine() / os.path.isfile() / os.access() / os.environ 取事实，不读文件、不写文件；
测试里直接打桩这几个函数。

client_is_mobile()：学员是不是在豆包手机 App 上用（看不到也没法扫自己手机屏幕上的二维码，改用手机号 + 验证码登录抖音）。
平台把客户端信息放在 DOUBAO_OFFICE_CLIENT_INFO（JSON），2026-10-23 实测 doubao_device_platform：
Android 手机 android、iPhone iphone、电脑客户端 desktop。只认这两个手机值，平板等没测过的、变量缺失或读不懂的都按电脑端扫码。
"""
import json
import os
import platform

PLATFORM_BROWSER = "/opt/browser/chrome"

# 依赖安装的 pip 镜像：火山内网 → 火山公网 → 清华 → 阿里云 → 腾讯云（设计 6.5）→ 官方 PyPI 兜底
# （2026-10-22 云电脑实测：火山两个镜像缺新版本、清华 403 时，官方 PyPI 能装全）。
# 优先用的是即用客服打包好的依赖（depbundle），这份列表是它用不了时的退路
PIP_MIRRORS = [
    "https://mirrors.ivolces.com/pypi/simple/",
    "https://mirrors.volces.com/pypi/simple/",
    "https://pypi.tuna.tsinghua.edu.cn/simple/",
    "https://mirrors.aliyun.com/pypi/simple/",
    "https://mirrors.cloud.tencent.com/pypi/simple/",
    "https://pypi.org/simple/",
]

# 豆包手机 App 的 doubao_device_platform（实测值）；app_id 不用：平板上的豆包 App 很可能和手机是同一个
MOBILE_PLATFORMS = ("android", "iphone")

UNSUPPORTED_STATUS = "unsupported_env"
UNSUPPORTED_SAY = "这个版本是豆包云电脑专用的，这台电脑用不了。请联系即用客服获取普通版安装链接。"


def unsupported_next(reason: str) -> str:
    """NEXT：转告学员、暂停；把检查结果原样回报，方便即用客服判断是不是平台改了识别用的变量"""
    return "把 SAY 转告学员，流程暂停，不要尝试绕过。把下面的检查结果原样回报给即用客服：" + str(reason)[:200]


def check():
    """返回 (ok, reason)。ok 为 False 时 reason 说明哪一条没通过（给 agent 和即用客服看，不含敏感信息）"""
    system, machine = platform.system(), platform.machine()
    if system != "Linux" or machine != "x86_64":
        return False, "系统不是 Linux x86_64（%s %s）" % (system or "?", machine or "?")
    if not (os.path.isfile(PLATFORM_BROWSER) and os.access(PLATFORM_BROWSER, os.X_OK)):  # 目录也算 X_OK
        return False, "找不到平台浏览器 %s" % PLATFORM_BROWSER
    if not (os.environ.get("DOUBAO_SANDBOX_TYPE") or "DoubaoWorkVM" in os.environ.get("BROWSER_USER_AGENT", "")):
        return False, "没有豆包云电脑的环境变量（DOUBAO_SANDBOX_TYPE、BROWSER_USER_AGENT）"
    return True, ""


def client_is_mobile(environ=None) -> bool:
    """学员是不是在豆包手机 App 上用（每条命令都是新进程，每次重新读，不缓存）"""
    raw = (os.environ if environ is None else environ).get("DOUBAO_OFFICE_CLIENT_INFO", "")
    try:
        info = json.loads(raw)
    except ValueError:
        return False
    v = info.get("doubao_device_platform") if isinstance(info, dict) else None
    return isinstance(v, str) and v.strip().lower() in MOBILE_PLATFORMS
